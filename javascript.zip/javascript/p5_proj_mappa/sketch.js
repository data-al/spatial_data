let myMap;
let increase_radius = 0;
let canvas;
const mappa = new Mappa('Leaflet');
const options = {
  lat: 55.956062,
  lng: 40.685939,
  zoom: 3.5,
  style: "https://cartodb-basemaps-{s}.global.ssl.fastly.net/light_all/{z}/{x}/{y}.png"
  //style: "http://{s}.tile.osm.org/{z}/{x}/{y}.png"
}

function preload() {
  airports_data = loadTable('5_airports.csv', 'header', 'csv')
}

function setup() {
  canvas = createCanvas(1700, 900);
  myMap = mappa.tileMap(options);
  myMap.overlay(canvas);
  angleMode(DEGREES);

  airports_data = loadTable('5_airports.csv', 'csv', 'header')

  // Only redraw the airports_data when the map change and not every frame.
  //myMap.onChange(draw);
}

function draw() {
  // Clear the previous canvas on every frame
  clear();

  //L.marker([50.5, 30.5]).addTo(map);

  let fcm = 2 * frameCount % 360;
  let frame_forward = map(fcm, 0, 360, 0, 360);
  let frame_backwards = map(fcm, 0, 360, 360, 0);

  for (let i = 0; i < airports_data.getRowCount(); i++) {
    const longitude = Number(airports_data.getString(i, 'longitude_deg'));
    const latitude = Number(airports_data.getString(i, 'latitude_deg'));
    const icao = String(airports_data.getString(i, 'ident'));

    if (myMap.map.getBounds().contains({ lat: latitude, lng: longitude })) {
      // Transform lat/lng to pixel position
      const airport = myMap.latLngToPixel(latitude, longitude);
      distance = dist(mouseX, mouseY, airport.x, airport.y);

      if (distance < 15) {
        increase_radius = 150;


        strokeWeight(0.8);
        stroke(10, 10, 10);
        textSize(11);
        textFont('Callibri');
        textAlign(CENTER, CENTER);
        text(concat(icao, ": \nSNOW expected in \n3h; Negative capacity impact \nestimated\nD-1 analysis sugests \ndelays on 5 \narrivals and \n8 departures "), airport.x, airport.y);
      } else {
        increase_radius = 0;
      }

      strokeWeight(3);
      //noFill();
      fill(100,0,0,20);
      stroke(103, 191, 138);
      arc(airport.x,
        airport.y,
        20 + increase_radius,
        20 + increase_radius,
        frame_forward,
        frame_forward + 220);

      stroke(255, 127, 14);
      arc(airport.x,
        airport.y,
        10 + increase_radius,
        10 + increase_radius,
        frame_backwards,
        frame_backwards + 180);

      stroke(214,39,40);
      arc(airport.x,
        airport.y,
        2 + increase_radius,
        2 + increase_radius,
        frame_forward,
        frame_forward + 100);

      stroke(0, 107, 164);
      arc(airport.x,
        airport.y,
        30 + increase_radius,
        30 + increase_radius,
        frame_backwards + 30,
        frame_backwards + 230);

    }

  }





}

