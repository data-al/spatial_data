function setup() {
  createCanvas(400, 400);
  angleMode(DEGREES);
}

function draw() {
  background(0);
  translate(200,200);
  rotate(-90);
  
  let hr = hour();
  let mn = minute();
  let sc = second();

  strokeWeight(20);
  noFill();
  stroke(150,100,255, 180);
  let secondsAngle = map(sc, 0, 59, 0, 360);
  arc(0,0,300,300,0,secondsAngle);

  strokeWeight(20);
  noFill();
  stroke(150,255,100, 180);
  let minutesAngle = map(mn, 0, 59, 0, 360);
  arc(0,0,250,250,0,minutesAngle);

  strokeWeight(20);
  noFill();
  stroke(255,100,150, 180);
  let hoursAngle = map(hr % 12, 0, 12, 0, 360);
  arc(0,0,200,200,0,hoursAngle);

  stroke(255);
  point(0,0)
  text(sc)
}
