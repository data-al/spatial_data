let raw_data;
let my_map;
let canvas;
const mappa = new Mappa('Leaflet');
const options = {
  lat: 55.956062, 
  lng: 15.685939,
  zoom: 3.5,
  style: "http://{s}.tile.osm.org/{z}/{x}/{y}.png"
}

function preload() {
    raw_data = loadTable(
        '5_airports.csv', 
        //'test.csv',
        'header', 'csv');  
}

function setup() {
    canvas = createCanvas(800,800);
    my_map = mappa.tileMap(options);
    my_map.overlay(canvas);
  }

function draw() {
  clear();    
  for (let row of raw_data.rows) {
    //console.log(row);
    let icao = row.get('ident');
    let lat = row.get('latitude_deg');
    let lon = row.get('longitude_deg');
    let elev = row.get('elevation_ft');
    let pix = my_map.latLngToPixel(lat, lon);
    // //print(String(lon[1]), ' And something else');
    ellipse(lat, lon, 200, 200);
  }
  noLoop();
}
