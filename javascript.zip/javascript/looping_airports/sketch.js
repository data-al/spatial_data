let myMap;
let canvas;
const mappa = new Mappa('Leaflet');

const options = {
  lat: 55.956062,
  lng: 40.685939,
  zoom: 3.5,
  style: "https://cartodb-basemaps-{s}.global.ssl.fastly.net/light_all/{z}/{x}/{y}.png"
  //style: "https://cartodb-basemaps-{s}.global.ssl.fastly.net/dark_all/{z}/{x}/{y}.png"
}

function setup() {
  canvas = createCanvas(1700, 900);
  myMap = mappa.tileMap(options);
  myMap.overlay(canvas)

  airports_data = loadTable('5_airports_new.csv', 'csv', 'header')

  // Only redraw the airports_data when the map change and not every frame.
  myMap.onChange(drawairports_data);

  fill(70, 203, 31);
  stroke(100);
}

function draw() {
}

function drawairports_data() {
  // Clear the canvas
  clear();

  for (let i = 0; i < airports_data.getRowCount(); i++) {
    const longitude = Number(airports_data.getString(i, 'longitude_deg'));
    const latitude = Number(airports_data.getString(i, 'latitude_deg'));

    console.log(longitude, latitude);
    if (myMap.map.getBounds().contains({ lat: latitude, lng: longitude })) {
      // Transform lat/lng to pixel position
      const pos = myMap.latLngToPixel(latitude, longitude);
      
      ellipse(pos.x, pos.y, 20, 20);
    }

  }
}